from turtle import *

shape('turtle')
color('green')

for i in range(4):
    forward(100)
    left(90)

mainloop()
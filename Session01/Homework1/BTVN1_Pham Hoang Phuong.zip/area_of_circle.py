radius=int(input("Radius?"))
pi=3.141592653589793
area=pi*radius**2
print("Area =", area)

from turtle import *

speed(-1)
shape('turtle')
color('green')

for i in range(36):
    circle(100)
    left(10)


   

mainloop()
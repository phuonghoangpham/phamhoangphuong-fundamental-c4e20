from turtle import *

shape('turtle')
color('green')

circle(100)

mainloop()
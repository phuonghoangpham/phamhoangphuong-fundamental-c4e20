from turtle import *

shape('turtle')
color('green')

for i in range(6):
    circle(100)
    left(60)

mainloop()
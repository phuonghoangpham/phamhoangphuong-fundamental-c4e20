celc=int(input("Enter the temperature in Celcius?"))
fahr=celc*1.8+32
print(celc, "(C) =", fahr, "(F)")
